(function ($) {
  'use strict';
  new ClipboardJS('.btn-clipboard');
})(jQuery);